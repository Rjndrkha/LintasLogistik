<!DOCTYPE html>
<html dir="ltr" lang="en-US">

    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- Google Fonts
        ============================================= -->
        <link href='https://fonts.googleapis.com/css?family=Lato:400,900,700,300' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <!-- Stylesheets
        ============================================= -->
        <link rel="stylesheet" href="<?php echo e(url('assets/css/plugin.css')); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo e(url('assets/css/responsive.css')); ?>" type="text/css" />
        <?php echo $__env->yieldContent('additional-css'); ?>
        <!-- JavaScripts
        ============================================= -->
        <script type="text/javascript" src="<?php echo e(url('assets/js/jquery.js')); ?>"></script>
        <?php echo $__env->yieldContent('script-after-jquery'); ?>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <?php echo $__env->yieldContent('title'); ?>
        
    </head>

    <body onload="hideTotal()">
        <div id="preloader">
            <div id="status">
                <img src="<?php echo e(url('assets/img/custom/header.png')); ?>" alt="" />
            </div>
        </div>

        <!-- MAIN WRAPPER
        ============================================= -->
        <div id="main-wrapper" class="clearfix">

            <!-- HEADER
            ============================================= -->
             <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- HEADER END -->

             <?php echo $__env->yieldContent('content'); ?>
           
            
            <!-- FOOTER START
            ============================================= -->
             <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- FOOTER END -->

        </div>
        <!-- MAIN WRAPPER END -->

        <!-- Footer Scripts
        ============================================= -->
        <!-- External -->
        <script type="text/javascript" src="<?php echo e(url('assets/js/plugin.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('assets/js/main.js')); ?>"></script>
        <?php echo $__env->yieldContent('additional-js'); ?>
        
    </body>
</html><?php /**PATH D:\apps\xampp\htdocs\listaslogistik-website\lintasLogistik\resources\views/layouts/main.blade.php ENDPATH**/ ?>